<?php
/**
 * Bootstrap file to initiate core files.
 */
include 'styles.php';
include 'block-patterns.php';
include 'template-functions.php';
include 'theme-info.php';
