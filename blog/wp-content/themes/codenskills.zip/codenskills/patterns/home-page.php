<?php
 /**
  * Title: Home Page
  * Slug: gutenify-blog/home-page
  * Categories: gutenify-blog
  */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"},"blockGap":"0px"}}} -->
<div class="wp-block-group alignfull" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px">
<!-- wp:pattern {"slug":"gutenify-blog/feature-post-section"} /-->
<!-- wp:pattern {"slug":"gutenify-blog/feature-category-section"} /-->
<!-- wp:pattern {"slug":"gutenify-blog/post-list-with-sidebar"} /-->
</div>
<!-- /wp:group -->
