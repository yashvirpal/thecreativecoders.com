
    <footer class="d-flex justify-content-around list-unstyled">
        <p>&copy; <?php echo date( 'Y' ); ?> CodeNskills. All rights reserved.</p>
        <?php wp_nav_menu( array( 'menu' => 'Privacy', 'container' => false, 'menu_class' => 'd-flex gap-3 footer-nav list-unstyled' ) ); ?>
    </footer>

    <?php wp_footer(); ?>
    </body>
    </html>
    