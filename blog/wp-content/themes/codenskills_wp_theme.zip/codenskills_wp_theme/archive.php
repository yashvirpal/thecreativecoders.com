<?php get_header(); ?>

<section class="container mt-5">
    <div class="row">
        <div class="col-lg-12">
            <header class="page-header mb-5">
                <h1 class="page-title">
                    <?php
                        if (is_category()) {
                            single_cat_title();
                        } elseif (is_tag()) {
                            single_tag_title();
                        } elseif (is_author()) {
                            echo 'Author: ' . get_the_author();
                        } elseif (is_day()) {
                            echo 'Daily Archives: ' . get_the_date();
                        } elseif (is_month()) {
                            echo 'Monthly Archives: ' . get_the_date('F Y');
                        } elseif (is_year()) {
                            echo 'Yearly Archives: ' . get_the_date('Y');
                        } else {
                            echo 'Archives';
                        }
                    ?>
                </h1>
            </header>

            <div class="row">
                <?php if (have_posts()) : ?>
                    <?php while (have_posts()) : the_post(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <?php if ( has_post_thumbnail() ) : ?>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail( 'medium', array( 'class' => 'img-fluid rounded' ) ); ?>
                                    </a>
                                <?php endif; ?>
                                <h3><a href="<?php the_permalink(); ?>" style="color: #64ffda;"><?php the_title(); ?></a></h3>
                                <p><?php the_excerpt(); ?></p>
                                <p class="blog-card__meta d-flex justify-content-between">
                                    <span class="categories"><?php the_category( ', ' ); ?></span>
                                    <span class="posted-on">
                                        <time class="published" datetime="<?php echo get_the_date( 'c' ); ?>">
                                            <?php echo get_the_date(); ?>
                                        </time>
                                    </span>
                                </p>
                            </div>
                        </div>
                    <?php endwhile;  ?>

        <!-- Pagination -->
        <div class="pagination d-flex justify-content-center mt-4">
            <?php
            the_posts_pagination(array(
                'mid_size'  => 2,
                'prev_text' => __('« Prev', 'textdomain'),
                'next_text' => __('Next »', 'textdomain'),
                'screen_reader_text' => ' ',
            ));
            ?>
        </div>

        <?php else : ?>
            <p>No posts found.</p>
        <?php endif; ?>
            </div>
            
        </div>
    </div>
</section>

<?php get_footer(); ?>
