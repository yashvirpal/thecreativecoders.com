<?php
/**
 * Template Name: Extract Geolocation by IP Address
 */
get_header(); 
?>
<section class="container mt-5">
    <div class="row">
        <div class="col-lg-12 mx-auto">
            <article class="post">
                <h1><?php the_title(); ?></h1>

                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="post-thumbnail">
                        <?php the_post_thumbnail( 'large', array( 'class' => 'img-fluid rounded' ) ); ?>
                    </div>
                <?php endif; ?>

                <div class="post-content mt-4">
                    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                        <?php //the_content(); ?>
                    <?php endwhile; endif; ?>
                </div>

                <!-- Post Meta -->
                <div class="post-meta mt-4">
                    <p>Posted on <?php echo get_the_date(); ?> in <?php the_category( ', ' ); ?></p>
                </div>

                

            </article>
        </div>
        <main>
    <div class="container">
    
        <h2>Extract Geolocation by IP Address</h2>
        <p>Enter an IP address to get its location.</p>

        <form method="POST">
            <input type="text" name="ip" placeholder="Enter IP Address">
            <button type="submit">Get Location</button>
        </form>

        <?php
        class Request {
            public function getIpAddress() {
                if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                    return $_SERVER['HTTP_CLIENT_IP'];
                } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                    return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
                } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
                    return $_SERVER['REMOTE_ADDR'];
                }
                return 'UNKNOWN';
            }

            public function getLocation($ip) {
                $ch = curl_init("http://ipwhois.app/json/{$ip}");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $json = curl_exec($ch);
                curl_close($ch);
                return json_decode($json, true);
            }
        }

        $requestModel = new Request();
        $ip = isset($_POST["ip"]) ? sanitize_text_field($_POST["ip"]) : $requestModel->getIpAddress();
        $geoLocationData = $requestModel->getLocation($ip);

        if (!empty($geoLocationData) && isset($geoLocationData['country'])) {
            echo "<p><strong>IP Address:</strong> " . esc_html($geoLocationData['ip']) . "</p>";
            echo "<p><strong>Country:</strong> " . esc_html($geoLocationData['country']) . "</p>";
            echo "<p><strong>Region:</strong> " . esc_html($geoLocationData['region']) . "</p>";
            echo "<p><strong>City:</strong> " . esc_html($geoLocationData['city']) . "</p>";
            echo "<p><strong>Postal Code:</strong> " . esc_html($geoLocationData['postal']) . "</p>";
            echo "<p><strong>Latitude:</strong> " . esc_html($geoLocationData['latitude']) . "</p>";
            echo "<p><strong>Longitude:</strong> " . esc_html($geoLocationData['longitude']) . "</p>";
            echo "<p><strong>ISP:</strong> " . esc_html($geoLocationData['isp']) . "</p>";
        } else {
            echo "<p>Invalid IP address or data not found.</p>";
        }
        ?>
    </div>
</main>
    </div>
</section>


<?php get_footer(); ?>
