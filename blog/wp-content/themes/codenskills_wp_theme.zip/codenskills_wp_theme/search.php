<?php get_header(); ?>

<section class="container mt-5">
    <h1 class="mb-4">Search Results for: <?php echo get_search_query(); ?></h1>

    <div class="row">
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="post-thumbnail">
                                <?php the_post_thumbnail( 'medium', array( 'class' => 'img-fluid' ) ); ?>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h3><a href="<?php the_permalink(); ?>" style="color: #64ffda;"><?php the_title(); ?></a></h3>
                            <p><?php the_excerpt(); ?></p>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else : ?>
            <p>No results found for "<?php echo get_search_query(); ?>".</p>
        <?php endif; ?>
    </div>

    <div class="pagination mt-4">
        <?php echo paginate_links(); ?>
    </div>
</section>

<?php get_footer(); ?>
