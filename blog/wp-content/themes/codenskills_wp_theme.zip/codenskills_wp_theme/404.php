<?php get_header(); ?>

<section class="container mt-5 text-center">
    <h1>404 - Page Not Found</h1>
    <p>Sorry, but the page you were looking for could not be found.</p>
    <a href="<?php echo home_url(); ?>" class="btn btn-primary mt-3">Return to Home</a>
</section>

<?php get_footer(); ?>
