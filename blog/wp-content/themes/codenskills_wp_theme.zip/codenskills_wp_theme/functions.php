<?php
    function codenskills_theme_setup() {
        // Add theme support for title and post thumbnails
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );
    }

    function codenskills_enqueue_scripts() {
        // Enqueue Google Fonts
        wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap', array(), null );
        
        // Enqueue Bootstrap
        wp_enqueue_style( 'bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css' );
        wp_enqueue_script( 'bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js', array(), null, true );
        
        // Enqueue main stylesheet
        wp_enqueue_style( 'main-style', get_stylesheet_uri() );
    }

    add_action( 'wp_enqueue_scripts', 'codenskills_enqueue_scripts' );
    add_action( 'after_setup_theme', 'codenskills_theme_setup' );

    // Register primary menu
    function codenskills_register_menus() {
        register_nav_menus( array(
            'primary' => __( 'Primary Menu', 'codenskills' ),
        ));
    }
    add_action( 'init', 'codenskills_register_menus' );
    ?>
