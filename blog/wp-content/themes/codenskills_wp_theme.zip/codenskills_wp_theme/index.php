    <?php get_header(); ?>

    <section class="hero">
        <h1>Insights and Tips on <span class="fw-bold">Web Development</span></h1>
        <h3>Explore our <span class="fw-bold">methods and view</span> of the web’s evolution.</h3>
    </section>

    <section class="container mt-5">
        <div class="row">
            
            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <?php the_post_thumbnail( 'medium', array( 'class' => 'img-fluid rounded' ) ); ?>
                        <?php endif; ?>
                        <h3><a href="<?php the_permalink(); ?>" style="color: #64ffda;"><?php the_title(); ?></a></h3>
                        <p><?php the_excerpt(); ?></p>
                        <p class="blog-card__meta d-flex justify-content-between">
                            <span class="categories"><?php the_category( ', ' ); ?></span>
                            <span class="posted-on">
                                <time class="published" datetime="<?php echo get_the_date( 'c' ); ?>">
                                    <?php echo get_the_date(); ?>
                                </time>
                            </span>
                        </p>
                    </div>
                </div>
            <?php endwhile; ?>

        <!-- Pagination -->
        <div class="pagination d-flex justify-content-center mt-4">
            <?php
            the_posts_pagination(array(
                'mid_size'  => 2,
                'prev_text' => __('« Prev', 'textdomain'),
                'next_text' => __('Next »', 'textdomain'),
                'screen_reader_text' => ' ',
            ));
            ?>
        </div>

        <?php else : ?>
            <p>No posts found.</p>
        <?php endif; ?>
        </div>
    </section>

    <?php get_footer(); ?>
    
