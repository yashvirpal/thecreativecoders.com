<?php get_header(); ?>

<section class="container mt-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <article class="post">
                <h1><?php the_title(); ?></h1>

                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="post-thumbnail">
                        <?php the_post_thumbnail( 'large', array( 'class' => 'img-fluid rounded' ) ); ?>
                    </div>
                <?php endif; ?>

                <div class="post-content mt-4">
                    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                        <?php the_content(); ?>
                    <?php endwhile; endif; ?>
                </div>

                <!-- Post Meta -->
                <div class="post-meta mt-4">
                    <p>Posted on <?php echo get_the_date(); ?> in <?php the_category( ', ' ); ?></p>
                </div>

                <!-- Comments Section -->
                <div class="comments-section mt-5">
                    <?php if ( comments_open() || get_comments_number() ) : ?>
                        <h3 class="mb-4">Leave a Comment</h3>
                        <?php
                        $comments_args = array(
                            'class_submit' => 'btn btn-primary',  // Add Bootstrap class to the submit button
                            'label_submit' => 'Submit Comment',
                            'comment_field' => '<div class="form-group"><textarea id="comment" name="comment" class="form-control" rows="5" placeholder="Enter your comment here"></textarea></div>',
                            'fields' => array(
                                'author' => '<div class="form-group"><input id="author" name="author" type="text" class="form-control" placeholder="Your Name" /></div>',
                                'email' => '<div class="form-group"><input id="email" name="email" type="email" class="form-control" placeholder="Your Email" /></div>',
                                'url' => '<div class="form-group"><input id="url" name="url" type="url" class="form-control" placeholder="Your Website (optional)" /></div>',
                            ),
                        );
                        comment_form( $comments_args ); 
                        ?>

                        <!-- Display comments -->
                        <h4 class="mt-5">Comments</h4>
                        <?php if ( have_comments() ) : ?>
                            <ul class="comment-list list-unstyled">
                                <?php wp_list_comments(); ?>
                            </ul>
                        <?php endif; ?>

                    <?php endif; ?>
                </div>

            </article>
        </div>
    </div>
</section>

<?php get_footer(); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
    // Find all <pre> elements with the 'wp-block-code' class
    const codeBlocks = document.querySelectorAll('pre.wp-block-code');

    codeBlocks.forEach(function (block, index) {
        // Create a container to wrap both the code block and the button
        const codeWrapper = document.createElement('div');
        codeWrapper.classList.add('code-wrapper');
        block.parentNode.insertBefore(codeWrapper, block);
        codeWrapper.appendChild(block);

        // Create a copy button
        const copyButton = document.createElement('button');
        copyButton.innerText = 'Copy';
        copyButton.classList.add('copy-btn');
        copyButton.setAttribute('data-code-block', 'code-block-' + index);

        // Insert the button into the wrapper (outside the code block)
        codeWrapper.appendChild(copyButton);

        // Set an ID for the code block to reference it
        block.setAttribute('id', 'code-block-' + index);

        // Add copy functionality
        copyButton.addEventListener('click', function () {
            const codeText = block.innerText; // Get the code text
            
            // Create a temporary textarea to copy the text
            const tempTextarea = document.createElement('textarea');
            tempTextarea.value = codeText;
            document.body.appendChild(tempTextarea);
            tempTextarea.select();
            document.execCommand('copy');
            document.body.removeChild(tempTextarea);

            // Change the button text to indicate success
            copyButton.innerText = 'Copied!';
            setTimeout(() => {
                copyButton.innerText = 'Copy';
            }, 2000); // Reset the button text after 2 seconds
        });
    });
});

</script>
